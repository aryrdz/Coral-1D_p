      Program luminosities
      implicit real*8 (a-h,o-z)
C
      open(unit=30,file=FILE1)
      read(30,*)
      read(30,*)
      read(30,*)
      read(30,'(38x,F7.1)')vwindlow
      read(30,'(38x,F8.1)')twindlow                                                                              
      read(30,'(38x,ES13.4)')amlow1
      read(30,'(38x,ES13.4)')amlow2
      read(30,'(38x,ES13.4)')amlow3
      read(30,'(38x,ES13.4)')time1
      read(30,'(38x,ES13.4)')time2
      read(30,'(38x,ES13.4)')timefin
      read(30,*)
      read(30,'(38x,ES13.4)')AbH_H                                                                               
      read(30,'(38x,ES13.4)')
     &     AbHe_H                                                                                              
      read(30,'(38x,ES13.4)')'AbC_H                               :',                                         
     &     AbC_H                                                                                               
      read(30,'(38x,ES13.4)')'AbN_H                               :',                                         
     &     AbN_H                                                                                               
      read(30,'(38x,ES13.4)')'AbO_H                               :',
      &     AbO_H
      read(30,'(38x,ES13.4)')'AbS_H                               :',                                         
     &     AbS_H                                                                                               
      read(30,'(38x,ES13.4)')'AbAr_H                              :',                                         
     &     AbAr_H                                                                                              
      read(30,'(38x,ES13.4)')'AbNe_H                              :',                                         
     &     AbNe_H                                                                                              
      read(30,'(38x)')'----------Simulation stuff- --------'                                                  
      if (imet .eq. 0) then                                                                                    
         read(30,'(38x)')'Solver:        2o. order Godunov'                                                   
      endif                                                                                                    
      if (imet .eq. 1) then                                                                                    
         read(30,'(38x)')'Solver:        1er order Godunov'                                                   
      endif                                                                                                    
      if (imet .eq. 2) then                                                                                    
         read(30,'(38x)')'Solver:         Predictor-Corrector'                                                
      endif                                                                                                    
      if (imet .eq. 2) then                                                                                    
         read(30,'(38x)')'Solver:         Fred-Lax'                                                           
      endif                                                                                                    
      read(30,'(38x,ES13.4)')'Maximum Radius [pc]                 :',                                         
     &     RMAX/3.08e18                                                                                        
      read(30,'(38x,ES13.4)')'Maximum Time   [yr]                 :',                                         
     &     TMAX/3.15e7                                                                                         
      read(30,'(38x,ES13.4)')'Output Time    [yr]                 :',                                         
     &     dtprint/3.15e7                                                                                      
      read(30,'(38x,I7)')'Number of cells                     :',NR                                           
      read(30,'(38x,I6)')'Number of cells in the wind         :',Ncells                                       
      read(30,'(38x,F6.1)')'Courant Number                      :',Co                                         
      if (imet .ge. 2) then                                                                                    
         read(30,'(38x,F4.2)')'Artificial Viscosity          :',eta                                           
      endif                                                                                                    
      read(30,'(38x,F6.1)')' % flux phot for call photoion      :',
     &     perc_fot*100
      read(30,'(38x,F6.1)')' % flux temp for -> photoion/atomic :',                                           
     &     perc_temp*100                                                                                       
      read(30,'(38x,I6)')' Max iter before -> photoion        :',                                             
     &     iterat_limit                                                                                        
      read(30,'(38x,I6)')'Number of variables                 :',NEQ  
C     
      call readfiles(NR,NEQ)
      STOP
      END
C
      subroutine readfiles(NR,NEQ)
      implicit real*8 (a-h,o-z)      
      Dimension al4861(NR),al3727(NR),al4686(NR),al5007(NR),al5876(NR)
     &     ,al6716(NR),al6730(NR),amassion(NR)
      Dimension Amatrix(NR,NEQ)
      Dimension array(NEQ)
      Dimension PRIM(NEQ)
      Character*40 FILE1,FILE2
      Parameter(AMASS=1.674D-24,AK=1.38D-16,PC=3.08E18,PI=3.141592)
      Parameter(ALSUN=4e33,AMSUN=2e33)

      ITP=15
      WRITE(FILE1,1000)ITP

 1000 FORMAT('./perinotto__2/points',I2,'.dat')

      OPEN(UNIT=1,FILE=FILE1,STATUS='old')
C
C
      Do i=1,NR
         READ(1,*)(array(j),j=1,neq)
         amatrix(i,1:NEQ)=array(1:NEQ)
      Enddo
     
      close(1)

c         READ(1,*)R,PRIM(1),PRIM(2),PRIM(3),T
c     &        ,PRIM(4),PRIM(5),PRIM(6),PRIM(7),PRIM(8),DENHeIII,DENCII
c     &        ,PRIM(9),PRIM(10)
c     &        ,PRIM(11),PRIM(12),PRIM(13),PRIM(14),PRIM(15),PRIM(16)
c     &        ,PRIM(17),PRIM(18),PRIM(19),PRIM(20),PRIM(21),DENSII
c     &        ,PRIM(22),PRIM(23),PRIM(24),PRIM(25),PRIM(26),PRIM(27)
c     &        ,PRIM(28),PRIM(29),PRIM(30),denelec

 
c         
         call alumsandmass(AMATRIX,al4861,al3727,al4686,
     &     al5007,al5876,al6716,al6730,amassion,NR,NEQ)


C                                                                                                       
      Return
      End
C     
      subroutine alumsandmass(AMATRIX,al4861,al3727,al4686,
     &     al5007,al5876,al6716,al6730,amassion,NR,NEQ)
      implicit real*8 (a-h,o-z)
      PARAMETER(AMASS=1.674D-24,AK=1.38D-16,pi=3.141592)
      PARAMETER(NCOL=30,NLINE=230)
      Dimension dens(NCOL),temp(NLINE),coef4861(NCOL,NLINE)
     &     ,coef3727(NCOL,NLINE),coef4686(NCOL,NLINE)
     &     ,coef5007(NCOL,NLINE),coef5876(NCOL,NLINE)
     &     ,coef6716(NCOL,NLINE),coef6730(NCOL,NLINE)
      Dimension Amatrix(NR,NEQ)
      Dimension al4861(NR),al3727(NR),al4686(NR),al5007(NR),al5876(NR)
     &     ,al6716(NR),al6730(NR),amassion(NR)
      Real*8 R, denelec,nhii,nheii,nheiii,noiii,noiv,nsii,T,T1
      Real*8 em4861,em3727,em4686,em5007,em5876,em6716,em6730
      Real*8 DR,RMAX
      Integer i
      Common/coef/coef4861,coef3727,coef4686,coef5007,coef5876
     &     ,coef6716,coef6730
      Common/dentemp/dens,temp
      
      RMAX=0.1*3.08e18
      DR=RMAX/float(NR-1)
      
C
      call opentablesiones
C
      al4861(1:NR)=0.
      al3727(1:NR)=0.
      al4686(1:NR)=0.
      al5007(1:NR)=0.
      al5876(1:NR)=0.
      al6716(1:NR)=0.
      al6730(1:NR)=0.
      amassion(1:NR)=0.
C                                                                                                                 
      Do i=3,NR

         R=Amatrix(I,1)
         T=Amatrix(I,5)
         denelec=Amatrix(I,NEQ)
         nhii=Amatrix(I,8)
         nheii=Amatrix(I,10)
         nheiii=Amatrix(I,11)
         noiii=Amatrix(I,16)
         noiv=Amatrix(I,17)
         nsii=Amatrix(I,26)
         
C
         Fact=4.*pi*R**2.*denelec*DR
C
         If (T .lt. 1.e6) Then
            T1=T
            if(T .lt. 200) T1=200.
C     Hbeta
            em4861=bidiminterpol(T1,denelec,temp,dens,coef4861)
            if (em4861 .lt. 0) em4861=0.
            al4861(i)=Fact*nhii*em4861+al4861(i-1)
C     [OII]3727
            em3727=bidiminterpol(T1,denelec,temp,dens,coef3727)
            if (em3727 .lt. 0) em3727=0.
            al3727(i)=Fact*noiii*em3727+al3727(i-1)
c
C     [HeII]4686     
C
            em4686=bidiminterpol(T1,denelec,temp,dens,coef4686)
            if (em4686 .lt. 0) em4686=0.
            al4686(i)=Fact*nheiii*em4686+al4686(i-1)
c
C     [OIII]5007
            em5007=bidiminterpol(T1,denelec,temp,dens,coef5007)
            if (em5007 .lt. 0) em5007=0.
            al5007(i)=Fact*noiv*em5007+al5007(i-1)
c
C     [HeI]5876
            em5876=bidiminterpol(T1,denelec,temp,dens,coef5876)
            if (em5876 .lt. 0) em5876=0.
           al5876(i)=Fact*nheii*em5876+al5876(i-1)
c
C     [SII]6716
C     
           em6716=bidiminterpol(T1,denelec,temp,dens,coef6716)
           if (em6716 .lt. 0) em6716=0.
           al6716(i)=Fact*nsii*em6716+al6716(i-1)
c
C     [SII]6730
           em6730=bidiminterpol(T1,denelec,temp,dens,coef6730)
           if (em6730 .lt. 0) em6730=0.
            al6730(i)=Fact*nsii*em6730+al6730(i-1)

C
         Else
            al4861(i)=al4861(i-1)
            al3727(i)=al3727(i-1)   
            al4686(i)=al4686(i-1)
            al5007(i)=al5007(i-1)
            al5876(i)=al5876(i-1)
            al6716(i)=al6716(i-1)
            al6730(i)=al6730(i-1)
         Endif
C     Ionized Mass
         amassion(i)=Fact*AMASS*AMOL+amassion(i-1)
               print*,al4861(i),r,T1,denelec
      Enddo
C         
      close(19)

      return
      end
C
      subroutine opentablesiones
      implicit real*8 (a-h,o-z)
            PARAMETER (NCOL=30,NLINE=230)
      Dimension dens(NCOL),temp(NLINE),coef4861(NCOL,NLINE)
     &     ,coef3727(NCOL,NLINE),coef4686(NCOL,NLINE)
     &     ,coef5007(NCOL,NLINE),coef5876(NCOL,NLINE)
     &     ,coef6716(NCOL,NLINE),coef6730(NCOL,NLINE)
C
      Common/coef/coef4861,coef3727,coef4686,coef5007,coef5876
     &     ,coef6716,coef6730
      Common/dentemp/dens,temp
             
      save
       
      OPEN(UNIT=19,FILE='ABELION.EMISSIVITIES',STATUS='UNKNOWN')
C
 96   CONTINUE
      READ(19,*,ERR=96)(dens(j),j=1,NCOL)
      Do i=1,NLINE
         READ(19,*) temp(i),(coef4861(j,i),j=1,NCOL)
      EndDo
 97   CONTINUE
      READ(19,*,ERR=97)(dens(j),j=1,NCOL)
      Do i=1,NLINE
         READ(19,*)temp(i),(coef3727(j,i),j=1,NCOL)
      EndDo
 98   CONTINUE
      READ(19,*,ERR=98)(dens(j),j=1,NCOL)
      Do i=1,NLINE
         READ(19,*)temp(i),(coef4686(j,i),j=1,NCOL)
      EndDo
 99   CONTINUE
      READ(19,*,ERR=99)(dens(j),j=1,NCOL)
      Do i=1,NLINE
         READ(19,*)temp(i),(coef5007(j,i),j=1,NCOL)
      EndDo
 100  CONTINUE
      READ(19,*,ERR=100)(dens(j),j=1,NCOL)

      Do i=1,NLINE
         READ(19,*) temp(i),(coef5876(j,i),j=1,NCOL)
      EndDo
 101  CONTINUE
      READ(19,*,ERR=101)(dens(j),j=1,NCOL)
      Do i=1,NLINE
         READ(19,*) temp(i),(coef6716(j,i),j=1,NCOL)
      EndDo
 102  CONTINUE
      READ(19,*,ERR=102)(dens(j),j=1,NCOL)
      Do i=1,NLINE
         READ(19,*)temp(i),(coef6730(j,i),j=1,NCOL)
      EndDo
C             
C                                                                                                               
      return
      end
C                                 
      function bidiminterpol(Temp,den,ta,da,coef)
      implicit real*8 (a-h,o-z)
      PARAMETER (NCOL=30,NLINE=230)
      Dimension ta(NLINE),da(NCOL),coef(NCOL,NLINE)
      
      save      

      i=1
      k=2
      kd=2
      Do While (ta(i) .le. Temp .and. i .lt. NLINE)
          i=i+1
          k=i
      EndDo
      t0=ta(k-1)
      t1=ta(k)
      i=1
      Do While (da(i) .le. den .and. i .lt. NCOL)
         i=i+1
         kd=i
      EndDo
      d0=da(kd-1)
      d1=da(kd)
C                                              
      tc=(Temp-t0)/(t1-t0)
      dc=(den-d0)/(d1-d0)
C
      emissivity=(1.-tc)*(1.-dc)*coef(kd-1,k-1)+
     &     tc*(1.-dc)*coef(kd-1,k)+
     &     tc*dc*coef(kd,k)+
     &     (1.-tc)*dc*coef(kd,k-1)
C     
      bidiminterpol=emissivity
C                                                                                                                 
      Return
      End
C      
      Function ainterpol(X,FX,FY,Nmax)
C         
      implicit real*8 (a-h,o-z)
      DIMENSION FX(Nmax),FY(Nmax)
      
      save

      If(abs(X) .lt. 1.d-100) Then 
      ainterpol=FY(1)                                                   
      Else 
         Do i=2,Nmax   
            If (FX(i) .ge. X) Then                                             
               pend=(FY(i)-FY(i-1))/(FX(i)-FX(i-1))
               ainterpol=pend*(X-FX(i-1))+FY(i-1)
               return 
            EndIF        
         Enddo 
      Endif                                                                     
      Return                                                                 
      End 

  
