      program leetabla
      implicit real*8(a-h,o-z)
      parameter (ncoolgz=392)
      Dimension tgz(ncoolgz),degz(ncoolgz)
      Dimension hgz(2,ncoolgz),hegz(3,ncoolgz),cgz(7,ncoolgz)
      Dimension angz(8,ncoolgz),ogz(9,ncoolgz),anegz(11,ncoolgz)
      Dimension amggz(13,ncoolgz),sigz(15,ncoolgz)
      Dimension sgz(17,ncoolgz),clgz(18,ncoolgz)
      Dimension argz(19,ncoolgz)
      integer num,i
      character*100 fila1,fila2,fila3,fila4,fila5
      character*50 temptgz
C
      open(unit=22, file='EMISLOSS.DAT')
      read(22,1010)fila1
      read(22,1010)fila2
      read(22,1010)fila3
      read(22,1010)fila4
      read(22,1010)fila5
C      print*,fila5
C
      Do i=1,ncoolgz
         read(22,1010)temptgz
         read(temptgz(13:20),*)tgz(i)
         read(temptgz(27:36),*)degz(i)
         read(22,*)num,hgz(1,i),hgz(2,i)
         read(22,*)num,hegz(1,i),hegz(2,i),hegz(3,i)
         read(22,*)num,cgz(1,i),cgz(2,i),cgz(3,i),cgz(4,i),cgz(5,i)
     &        ,cgz(6,i),cgz(7,i)
         read(22,*)num,angz(1,i),angz(2,i),angz(3,i),angz(4,i),angz(5,i)
     &        ,angz(6,i),angz(7,i),angz(8,i)
         read(22,*)num,ogz(1,i),ogz(2,i),ogz(3,i),ogz(4,i),ogz(5,i)
     &        ,ogz(6,i),ogz(7,i),ogz(8,i),ogz(9,i)
         read(22,*)num,anegz(1,i),anegz(2,i),anegz(3,i),anegz(4,i)
     &        ,anegz(5,i),anegz(6,i),anegz(7,i),anegz(8,i),anegz(9,i)
     &        ,anegz(10,i),anegz(11,i)
         read(22,*)num,amggz(1,i),amggz(2,i),amggz(3,i),amggz(4,i)
     &        ,amggz(5,i),amggz(6,i),amggz(7,i),amggz(8,i)
     &        ,amggz(9,i),amggz(10,i),amggz(11,i),amggz(12,i)
     &        ,amggz(13,i)
         read(22,*)num,sigz(1,i),sigz(2,i),sigz(3,i),sigz(4,i),sigz(5,i)
     &        ,sigz(6,i),sigz(7,i),sigz(8,i),sigz(9,i),sigz(10,i)
     &        ,sigz(11,i),sigz(12,i),sigz(13,i),sigz(14,i),sigz(15,i)
         read(22,*)num,sgz(1,i),sgz(2,i),sgz(3,i),sgz(4,i),sgz(5,i)
     &        ,sgz(6,i),sgz(7,i),sgz(8,i),sgz(9,i),sgz(10,i)
     &        ,sgz(11,i),sgz(12,i),sgz(13,i),sgz(14,i),sgz(15,i)
     &        ,sgz(16,i),sgz(17,i)
         read(22,*)num,clgz(1,i),clgz(2,i),clgz(3,i),clgz(4,i),clgz(5,i)
     &        ,clgz(6,i),clgz(7,i),clgz(8,i),clgz(9,i),clgz(10,i)
     &        ,clgz(11,i),clgz(12,i),clgz(13,i),clgz(14,i),clgz(15,i)
     &        ,clgz(16,i),clgz(17,i),clgz(18,i)
         read(22,*)num,argz(1,i),argz(2,i),argz(3,i),argz(4,i),argz(5,i)
     &        ,argz(6,i),argz(7,i),argz(8,i),argz(9,i),argz(10,i)
     &        ,argz(11,i),argz(12,i),argz(13,i),argz(14,i),argz(15,i)
     &        ,argz(16,i),argz(17,i),argz(18,i),argz(19,i)
      enddo
 1010 Format(A)
 1011 Format(A,E13.3,5x,E13.3)
      end

