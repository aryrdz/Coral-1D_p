from scipy import integrate
import numpy as np

'''
    Calcula el numero de fotones de energia para H y He+ (hecho por Jackeline Suzett)
    Q = [2 PI Kb^3 L / c^2 h^3 sigma T] * Integral ( X^2 / (exp(x) - 1) ) dx
    CteNum = 2 PI Kb^3 L / c^2 h^3 sigma T
    Q = CteNum * Integral ( X^2 / (exp(x) - 1) ) dx
'''

Kb = 1.38E-23    #[Kb] = J K^-1, cte. Boltzmann
sigma = 5.67E-8  #[sigma] = J S^-1 m^-2 K^-4,  cte. Steffan-Boltzmann
h = 6.63E-34     #[h] = J S, cte. Planck
c = 3e8          #[c] = m s^-1, vel. de la luz
Pi = 3.1416

#Lee el archivo y las variables L (luminosidad star) y T (temperatura star)
modelo = np.genfromtxt("Mf_0.625_modelo.txt")
L = (10**(modelo[:,1]))*(4E26)
T = modelo[:,2]
#13.6ev = 2.17872E-18 J para H
#54.42ev = 8.718084E-18 para He+
#LimInf = 13.6 eV/(Kb*T) = 2.17872E-18 J/(Kb*T), LimSup = Infinito

rango = len(L)
i = 0
#Aqui calcula la integral
for x in range(0,rango):
    CteNum = (2*(Pi)*(Kb**3)*L[0+i])/((c**2)*(h**3)*sigma*T[0+i])
    invexp = lambda x: CteNum * ((x**2)/(np.exp(x)-1))
    #Aqui evalua los limites de la integral (invexp,LimInf,LimSup)
    ValorInt_H = integrate.quad(invexp, (2.17872E-18)/(Kb*T[0+i]), np.inf)
    ValorInt_He1 = integrate.quad(invexp, (8.718084E-18)/(Kb*T[0+i]), np.inf)
    #print(ValorInt_H[0])
    print(ValorInt_He1[0])
    #print ('%-25s' '%s' % (ValorInt_H[0],ValorInt_He1[0]))
    i=i+1


