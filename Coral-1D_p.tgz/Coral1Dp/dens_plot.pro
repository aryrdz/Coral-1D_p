close,/all
  NP=10
  NR=4000L
  nin=1
  nfin=8
  Rmax=1.0e18
  filebase="./perinotto__2/points"
  filebase2="./perinotto__2/points"
;
;;;;
;  
  NRNPT=(NR-2)*NP+2
  NCOL=36

  dr=Rmax/NR
  Rmin=dr/1
  a=dblarr(NCOL,NRNPT)
  a2=dblarr(NCOL,NRNPT)
  help,a
  ;
  !p.multi=[0,2,2]
  window,xsize=700,ysize=700
  for i=nin,nfin,1 do begin
;     
     itp=0+i
;
     exts='000'
     exts=exts+strcompress(string(itp),/remove_all)
     exts=strmid(exts,strlen(exts)-3,3)
     file=filebase+exts+".dat"
     file2=filebase2+exts+".dat"
;
     openr,1,file
     SKIP_LUN, 1, 1, /LINES
     readf,1,a
     close,1
;
     openr,2,file2
     SKIP_LUN, 2,1, /LINES
     readf,2,a2
     close,2   
;
     !x.range=[1e15,1e18]
;
     r=a(0,*)
     rho=a(3,*)
     temp=a(4,*)
     den=a(5,*)
     hi=a(6,*)
     hii=a(7,*)
     hei=a(8,*)
     heii=a(9,*)
     heiii=a(10,*)
     cii=a(11,*)
     ciii=a(12,*)
     civ=a(13,*)
     cv=a(14,*)
     oii=a(15,*)
     oiii=a(16,*)
     oiv=a(17,*)
     ov=a(18,*)
     ovi=a(19,*)
     neii=a(20,*)
     neiii=a(21,*)
     neiv=a(22,*)
     nev=a(23,*)
     nevi=a(24,*)
     sii=a(25,*)
     siii=a(26,*)
     siv=a(27,*)
     sv=a(28,*)
     svi=a(29,*)
     nii=a(30,*)
     niii=a(31,*)
     niv=a(32,*)
     nv=a(33,*)
     nvi=a(34,*)
     nelec=a(35,*)
     
     r2=a2(0,*)
     rho2=a2(3,*)
     temp2=a2(4,*)
     den2=a2(5,*)
     hi2=a2(6,*)
     hii=a2(7,*)     
     r=r
     r2=r2
     !y.title='density [cm!e-3!n]'
     !x.title=' '
     plot,r,den,yrange=[1e-12,2.5e9],ystyle=1,charsize=0.9,xstyle=1,thick=0.5,/ylog
;     oplot,r2,den2,linestyle=2
;     oplot,r,hii,linestyle=2
         !y.title='temperature [K]'
     plot,r,temp,yrange=[100,1e6],ystyle=1,charsize=0.9,xstyle=1,thick=0.5,/ylog
     !y.title='hydrogen [cm!e-3!n]'
     !x.title=' '
     plot,r,hii,/ylog,yrange=[1e-5,1e8],ystyle=1,charsize=0.9,xstyle=1,thick=0.5
     oplot,r,hi,linestyle=1
;     oplot,r,nelec,linestyle=2
     print,minmax(hi/(hi+hii))
     plot,r,hii/(hi+hii),/ylog,yrange=[1e-2,1.5],ystyle=1,charsize=0.9,xstyle=1,thick=0.5,/xlog,linestyle=0.
     oplot,r,hi/(hi+hii),linestyle=1
;     oplot,r,nelec/(hi+hii),linestyle=2
;     !y.title='helio [cm!e-3!n]'
;     !x.title=' '
;     plot,r,hei,/ylog,yrange=[1e-2,1e7],ystyle=1,charsize=0.9,xstyle=1,thick=0.5,/xlog
;     oplot,r,heii,linestyle=1
;     oplot,r,heiii,linestyle=2
;     !y.title='oxygen [cm!e-3!n]'
;     !x.title=' '
;     plot,r,oii,/ylog,yrange=[1e-7,1e2],ystyle=1,charsize=0.9,xstyle=1,thick=0.5,/xlog,linestyle=1
;     oplot,r,oiii,linestyle=2
;     oplot,r,oiv,linestyle=3
;     oplot,r,ov,symsize=0.5,psym=1
;     oplot,r,ovi,symsize=0.5,psym=2
;     !y.title='nytrogen [cm!e-3!n]'
;     !x.title=' '
;     plot,r,nii,/ylog,yrange=[1e-7,1e2],ystyle=1,charsize=0.9,xstyle=1,thick=0.5,/xlog,linestyle=1
;     oplot,r,niii,linestyle=2
;     oplot,r,niv,linestyle=3
;     oplot,r,nv,symsize=0.5,psym=1
;     oplot,r,nvi,symsize=0.5,psym=2
;     !y.title='sulfur [cm!e-3!n]'
;     !x.title=' '
;     plot,r,sii,/ylog,yrange=[1e-7,1e2],ystyle=1,charsize=0.9,xstyle=1,thick=0.5,/xlog,linestyle=1
;     oplot,r,siii,linestyle=2
;     oplot,r,siv,linestyle=3
;     oplot,r,sv,symsize=0.5,psym=1
;     oplot,r,svi,symsize=0.5,psym=2
;     !y.title='carbon [cm!e-3!n]'
;     !x.title=' '
;     plot,r,cii,/ylog,yrange=[1e-7,1e2],ystyle=1,charsize=0.9,xstyle=1,thick=0.5,/xlog,linestyle=1
;     oplot,r,ciii,linestyle=2
;     oplot,r,civ,linestyle=3
     print,'Salida=',itp

 wait,1
  endfor
end
